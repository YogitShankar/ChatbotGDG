problem_urls = [
    "https://codeforces.com/problemset/problem/1/A",  # Example URLs
    "https://codeforces.com/problemset/problem/2/B"
]

for url in problem_urls:
    scrape_problem(url)
    time.sleep(2)  # Respect rate limits
